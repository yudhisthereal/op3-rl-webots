# test_policy.py
# Webots controller to test trained DDPG policy
# Loads the saved model and demonstrates the agent's behavior

from controller import Supervisor
import numpy as np
import torch
import torch.nn as nn
import sys
import os

# Add parent directory to path to import model architecture
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'op3_ddpg_env'))

# ================== CONFIG ==================
TIMESTEP = 32
JOINT_NAMES = [
    "ShoulderR", "ShoulderL", "ArmUpperR", "ArmUpperL", "ArmLowerR",
    "ArmLowerL", "PelvYR", "PelvYL", "PelvR", "PelvL",
    "LegUpperR", "LegUpperL", "LegLowerR", "LegLowerL", "AnkleR",
    "AnkleL", "FootR", "FootL", "Neck", "Head"
]

CONTROL_JOINTS = ["ShoulderL", "ArmUpperL"]
TARGET = np.array([1.57, -1.57], dtype=np.float32)
MAX_STEPS = 200
NUM_TEST_EPISODES = 5

# Per-joint mechanical limits (Webots OP3)
ANGLE_LIMITS = {
    "ShoulderL": (-1.57, 1.57),
    "ArmUpperL": (-1.57, 1.57)
}

# ================== ENV SETUP ==================
robot = Supervisor()
motors, sensors = [], []

for name in CONTROL_JOINTS:
    m = robot.getDevice(name)
    s = m.getPositionSensor()
    s.enable(TIMESTEP)
    m.setPosition(0.0)
    motors.append(m)
    sensors.append(s)

episode_step = 0


def get_obs():
    return np.array([s.getValue() for s in sensors], dtype=np.float32)


def apply_action(action):
    """Clamp to joint-specific limits and apply."""
    for i, (m, a) in enumerate(zip(motors, action)):
        jname = CONTROL_JOINTS[i]
        low, high = ANGLE_LIMITS[jname]
        a = float(np.clip(a, low, high))
        m.setPosition(a)


def reset_env():
    """Forcefully reset both joints to zero."""
    global episode_step
    episode_step = 0
    for m in motors:
        m.setPosition(0.0)
    # Wait until sensor readings converge near zero
    while True:
        robot.step(TIMESTEP)
        obs = get_obs()
        if np.allclose(obs, [0.0, 0.0], atol=1e-3):
            break
    return get_obs()


# ================== MODEL ARCHITECTURE ==================
class MLP(nn.Module):
    def __init__(self, in_dim, out_dim, hidden=64):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_dim, hidden), nn.ReLU(),
            nn.Linear(hidden, hidden), nn.ReLU(),
            nn.Linear(hidden, out_dim)
        )

    def forward(self, x):
        return self.net(x)


# ================== LOAD MODEL ==================
checkpoint_path = os.path.join(os.path.dirname(__file__), '..', 'op3_ddpg_env', 'checkpoints', 'ddpg_model.pt')

if not os.path.exists(checkpoint_path):
    print(f"❌ Error: Model checkpoint not found at {checkpoint_path}")
    print("Please train the model first using op3_ddpg_env.py")
    robot.step(TIMESTEP)
    sys.exit(1)

print(f"Loading model from {checkpoint_path}...")
checkpoint = torch.load(checkpoint_path, map_location='cpu')

obs_dim = checkpoint['obs_dim']
act_dim = checkpoint['act_dim']

# Create actor network
actor = MLP(obs_dim, act_dim)
actor.load_state_dict(checkpoint['actor_state_dict'])
actor.eval()  # Set to evaluation mode

print("✅ Model loaded successfully!")
print(f"Testing policy for {NUM_TEST_EPISODES} episodes...")
print(f"Target angles: {TARGET}")
print("-" * 60)

# ================== TEST LOOP ==================
for ep in range(1, NUM_TEST_EPISODES + 1):
    obs = reset_env()
    total_reward = 0.0
    episode_step = 0
    min_dist = float('inf')
    
    for step in range(MAX_STEPS):
        episode_step = step + 1
        
        # Get action from trained policy (no exploration noise)
        obs_t = torch.tensor(obs, dtype=torch.float32)
        with torch.no_grad():
            action = actor(obs_t).numpy()
        
        # Apply action
        apply_action(action)
        robot.step(TIMESTEP)
        next_obs = get_obs()
        
        # Compute distance to target
        dist = np.linalg.norm(next_obs - TARGET)
        min_dist = min(min_dist, dist)
        
        # Simple reward for logging
        reward = -dist**2
        if dist < 0.01:
            reward += 5.0
        
        total_reward += reward
        obs = next_obs
        
        # Check if target reached
        if dist < 0.01:
            print(f"Episode {ep}/{NUM_TEST_EPISODES} | Steps: {episode_step:3d} | "
                  f"Final angles: [{next_obs[0]:6.3f}, {next_obs[1]:6.3f}] | "
                  f"Distance: {dist:.4f} | ✅ SUCCESS")
            break
    
    if dist >= 0.01:
        print(f"Episode {ep}/{NUM_TEST_EPISODES} | Steps: {episode_step:3d} | "
              f"Final angles: [{obs[0]:6.3f}, {obs[1]:6.3f}] | "
              f"Min distance: {min_dist:.4f} | Total reward: {total_reward:.3f}")
    
    # Small pause between episodes
    for _ in range(10):
        robot.step(TIMESTEP)

print("-" * 60)
print("✅ Testing completed!")
